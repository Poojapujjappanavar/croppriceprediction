import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import glob

# Path to the folder with your datasets
data_folder_path = "D:/SDP/sdp/static/"  # Update with the actual folder path

# List all CSV files in the folder
files = glob.glob(data_folder_path + "*.csv")

# Function to train and evaluate both models for each dataset
def train_and_evaluate_models(file_path, threshold=15):
    try:
        data = pd.read_csv(file_path)
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return
    
    # Check for required columns
    if not all(col in data.columns for col in ['Month', 'Year', 'Rainfall', 'WPI']):
        print(f"File {file_path} does not contain the required columns.")
        return

    # Select features and target
    features = data[['Month', 'Year', 'Rainfall']]
    target = data['WPI']
    
    # Check for empty features or target
    if features.empty or target.empty:
        print(f"File {file_path} has empty features or target after column selection.")
        return
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

    # Preprocessing pipeline for scaling and encoding
    preprocessor = ColumnTransformer(
        transformers=[
            ('month', OneHotEncoder(), ['Month']),
            ('scaler', StandardScaler(), ['Year', 'Rainfall'])
        ],
        remainder='passthrough'
    )

    # Define Decision Tree and Random Forest Regressor Pipelines
    dt_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', DecisionTreeRegressor(random_state=42, max_depth=10))
    ])
    
    rf_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', RandomForestRegressor(random_state=42, n_estimators=100, max_depth=10))
    ])

    # Fit both models
    dt_pipeline.fit(X_train, y_train)
    rf_pipeline.fit(X_train, y_train)

    # Make predictions with both models
    dt_predictions = dt_pipeline.predict(X_test)
    rf_predictions = rf_pipeline.predict(X_test)

    # Calculate metrics for both models
    for model_name, predictions in zip(
        ["Decision Tree Regressor", "Random Forest Regressor"],
        [dt_predictions, rf_predictions]
    ):
        mae = mean_absolute_error(y_test, predictions)
        mse = mean_squared_error(y_test, predictions)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_test, predictions)
        accuracy_within_threshold = calculate_accuracy_within_threshold(y_test, predictions, threshold)

        # Print results
        print(f"File: {file_path}")
        print(f"Model: {model_name}")
        print(f"Mean Absolute Error: {mae}")
        print(f"Root Mean Squared Error: {rmse}")
        print(f"R2 Score: {r2}")
        print(f"Accuracy within {threshold} units: {accuracy_within_threshold:.2f}%")
        print("-" * 30)

# Function to calculate accuracy within a specified threshold
def calculate_accuracy_within_threshold(y_test, predictions, threshold=5):
    absolute_errors = np.abs(y_test - predictions)
    accurate_predictions = (absolute_errors <= threshold).sum()
    accuracy = (accurate_predictions / len(y_test)) * 100
    return accuracy

# Loop through each file and train/evaluate the models
for file in files:
    train_and_evaluate_models(file, threshold=15)
