from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Fake user data for the sake of the example
users = {'admin': 'admin123'}

# Route for the login page
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if the user exists and the password matches
        if username in users and users[username] == password:
            return redirect(url_for('index'))  # Redirect to index.html after successful login
        else:
            return 'Invalid credentials. Please try again.', 401

    return render_template('login.html')  # If GET request, render the login page

# Route for the index page (after login)
@app.route('/index')
def index():
    return render_template('index.html')  # Display the index page

if __name__ == '__main__':
    app.run(debug=True)
